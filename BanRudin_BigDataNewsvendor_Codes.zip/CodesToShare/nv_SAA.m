%% Newsvendor with Features - Sample Average Approximation
% Input data must be separate; also need to specify validation and test
% data sets

clear all
loc = 'XXX';
cd(loc)

%load dataset
%load('EMERG.mat')

cvx_solver Mosek
cvx_save_prefs

ln = 3000; %cut off data
p = 500; %max memory lag

EMERG  = EMERG(1:ln+p+1,:);
DATE = EMERG(1:ln,1);
TIME = EMERG(1:ln,2);

CENSUS = EMERG(:,3); %need to start predicting from 1+p

%% The Newsvendor Problem -- SAA solution

b=30;
h=20;
r= b/(b+h);

lntr  = 12*7*16;
lnva = lntr/2; %validation data size
lnte=lnva;

%QSAA = sparse(lnva,1); %record q0fac, q1fac
%CostSAA = sparse(lnva,1); %in-sample cost
%ValSAA = sparse(lnva,1);

QSAA = sparse(lnte,1); %record q0fac, q1fac
CostSAA = sparse(lnte,1); %in-sample cost
TestSAA = sparse(lnte,1);

for t=lntr+lnva+1:lntr+lnva+lnte
    t
    clear q0 C dum1 dum2

    cvx_begin
        variables q0 C(lntr) dum1(lntr) dum2(lntr)
        minimize( sum(C)/lntr)
        subject to
            for i=1:lntr
                C(i) == (b+h)*(r*dum1(i)+(1-r)*dum2(i));
                dum1(i) >= 0;
                dum1(i) >= Demand(t-lntr+i-1)-q0;
                dum2(i) >= 0;
                dum2(i) >= q0-Demand(t-lntr+i-1); 
            end
            q0 >= 0;
    cvx_end

    QSAA(t-lntr-lnva,1) = q0;
    CostSAA(t-lntr-lnva,1) = cvx_optval;
    TestSAA(t-lntr-lnva,1) = nvcost(q0,Demand(t),b,h);
    
end

toc

save(strcat('nv_emerg_SAA_lntr_',num2str(lntr),'_lnte_',num2str(lnte),'.mat')) 

