%% Regularized (Ridge or Lasso) Newsvendor with Features
% Input data must be separate; also need to specify validation and test
% data sets

b=2.5/3.5;
h=1/3.5;
r= b/(b+h);

Valfac = sparse(lnva,1);
Costfac = sparse(lnva,1); %in-sample cost
QfacD = zeros(lnva,1);
if p==0 
    Features = [DayC, TimeC, Time];
    lF = length(Features(1,:));
else
    Features = [DayC, TimeC, Time, Past(:,[1:p])];
    lF = length(Features(1,:));
end      
Qfac = zeros(lnva,1+lF); 

tic
for t=lntr+lnva+1:lntr+lnva+lnte
    t-lntr-lnva
    FeaturesT = Features(t-lntr:t-1,:)./norm(Features(t-lntr:t-1,:),Inf);
    
    clear q0 q C dum1 dum2
    cvx_begin quiet
    variables q0 q(lF) C(lntr) dum1(lntr) dum2(lntr)
    minimize( sum(C)/lntr+lambda*norm(q,1)) %change to norm(q,2) for ridge
    subject to
        for i=1:lntr   
            C(i) == (b+h)*(r*dum1(i)+(1-r)*dum2(i));
            dum1(i) >= 0;
            dum1(i) >= Demand(t-lntr+i+delay-1)-q0-q'*FeaturesT(i,:)';
            dum2(i) >= 0;
            dum2(i) >= q0+q'*FeaturesT(i,:)'-Demand(t-lntr+i+delay-1); 
        end
            q0 >= 0;
            q  >= 0;
    cvx_end
    
    CVXSTATUS{t-lntr,1} = cvx_status;
    CPUTIME(t-lntr) = cvx_cputime;
    
    Qfac(t-lntr,1) = q0;
    Qfac(t-lntr,[2:1+lF]) = q;        
    Costfac(t-lntr,1) = cvx_optval;

    QfacD(t-lntr,1) = q0+q'*(Features(t,:)'./(norm(Features(t-lntr:t-1,:),Inf))');
    Valfac(t-lntr,1) = nvcost(q0+q'*(Features(t,:)'./(norm(Features(t-lntr:t-1,:),Inf))'),Demand(t+delay),b,h);

end
toc/10


%%
loc = 'XXX';
save(strcat(loc,'nv_emerg_reg_L1_',num2str(lambda),'_de_',num2str(delay),'_lntr_',num2str(lntr),'_lnte_',num2str(lnte),'_p_',num2str(p),'.mat')) 

