%% Newsvendor with Features solved via Kernal Optimization (ranking algorithm)
% Input data must be separate; also need to specify validation and test
% data sets

clear all
loc = 'XXX';
cd(loc)

%load data
%load(strcat('nv_emerg_prob_struct_opstat.mat')) 

len_demand = length(Demand);
kernel_weight=zeros(len_demand, 1);
lntr = 12*7*16; %training data size
lnva = lntr/2; %validation data size
lnte = lnva;
p = 12*14;
delay = 3; %no of shifts for decision

%bandvec = [0.06,0.08,0.1,0.12,0.14]; optimal: 0.08 Gaussian
bandvec = [0.08];
Blen = length(bandvec);

%% The Newsvendor Problem with features and delay
b=2.5/3.5;
h=1/3.5;
r= b/(b+h);

%CPUTIME = sparse(lnva,1);
Valfac = sparse(Blen,lnva);
%Costfac = sparse(lnva,1); %in-sample cost
QfacD = zeros(Blen,lnva);

if p==-36 
    Features = [TimeC];
    lF = length(Features(1,:));
elseif p==-24 
    Features = [DayC];
    lF = length(Features(1,:));
elseif p==-12 
    Features = [DayC, TimeC];
    lF = length(Features(1,:));
elseif p==0 
    Features = [DayC, TimeC, Time];
    lF = length(Features(1,:));
else
    Features = [DayC, TimeC, Time, Past(:,[1:p])];
    lF = length(Features(1,:));
end    
tic
for bi = 1:Blen
    bandwidth = bandvec(bi); 

    for t=lntr+lnva+1:lntr+lnva+100%lnte
%        t-lntr;    
        FeaturesT = zeros(size(Features(t-lntr:t,:)));
    
        for j=1:p
            FeaturesT(t-lntr:t,j) = Features(t-lntr:t,j)./norm(Features(t-lntr:t,j),Inf);
            %kernel_weight(i)= normpdf(norm(curr_feature-features(:,i))/bandwidth)/bandwidth;
        end
        kernel_weight = zeros(lntr,1);
    
        for i=1:lntr
            kernel_weight(i)= normpdf(norm(FeaturesT(t,:)-FeaturesT(t-lntr+i-1,:))/bandwidth);
%           kernel_weight(i)= (norm(FeaturesT(t,:)-FeaturesT(t-lntr+i-1,:))<=bandwidth)/(2*bandwidth);
        end     
        weights_normalisation_factor= sum(kernel_weight);
        kernel_cdf=zeros(1,lntr);
 
        [sDemand, Map] = sort(Demand(t-lntr+delay:t+delay-1));
        skernel_weight = kernel_weight(Map);
        
        for i=1:lntr
            ind_demand=sDemand<=sDemand(i);
            kernel_cdf(i)= sum(ind_demand.*skernel_weight)/weights_normalisation_factor;
        end
        %   plot(kernel_cdf)
        demand_range = Demand(t-lntr+delay:t+delay-1); 
        q0=demand_range(min(find(kernel_cdf>=b/(b+h))));
         
%       Qfac(t-lntr,1) = q0;
%       Costfac(t-lntr,1) = cvx_optval;
        QfacD(bi,t-lntr) = q0;
        Valfac(bi,t-lntr) = nvcost(q0,Demand(t+delay),b,h);

    end
end
toc/100

%%
save(strcat(loc,'nv_kernelG_de2_',num2str(delay),'_lntr_',num2str(lntr),'_lnte_',num2str(lnte),'_p_',num2str(p),'.mat')) 