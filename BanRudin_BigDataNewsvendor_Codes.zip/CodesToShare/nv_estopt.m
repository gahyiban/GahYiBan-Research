%% Newsvendor with Features- Estimate then Optimize
% Input data must be separate; also need to specify validation and test
% data sets

clear all
loc = 'XXX';
cd(loc)

%load data
%load(strcat('nv_emerg_prob_struct_opstat.mat')) 

cvx_solver Mosek
cvx_save_prefs

%DATA= [Day,Time,EMERG(:,3)]

%%
lntr = 12*7*16; %training data size
lnva = lntr/2; %validation data size

%pvec = 12*[20];
%ind= length(pvec);

delay = 3; %no of shifts for decision
ind=1;

%pvec = 12*[1];

%pvec = 12*[1,2,3,4,5];
%pvec = 12*[6,7,8,9];
%pvec = 12*[10,11,12];
pvec = 12*[0];

pind = length(pvec);

for i=1:pind
    p = pvec(i); 

%% The Newsvendor Problem with features
%rate = 10; %pounds per hour?
    b=2.5/3.5;
    h=1/3.5;
    r= b/(b+h);

%pvec = 6*[0]; %no. of past periods
    ll = 1;%length(pvec);

    Valfac = sparse(lnva,1);
    Costfac = sparse(lnva,1); %in-sample cost
    ResOpt = sparse(lnva,1); %in-sample residual
%BoundBeta = sparse(lnva,ll); %Bound
%BoundIID = sparse(lnva,ll); %Bound
    lF = 0;
    tic
    if p==0 
%        Features = [DayC, Time];
        Features = [DayC, TimeC,Time];
%        Features = normr(FeaturesR');
        lF = length(Features(1,:));
        else
%        Features = [DayC, TimeC, Time, Past(:,[1:p]), PastMean, OrderP(:,[1:p-1])];
%        Features = [DayC, TimeC, Time, Past(:,[1:p])];
        lF = length(Features(1,:)); 
    end
    toc

    Qfac = zeros(lnva,ll,1+lF); %record q0fac, q1fac
    QfacD = zeros(lnva,ll); 
    muD = zeros(lnva,ll); 
    sigmaD = zeros(lnva,ll);

%%
    j=1;

    for t=lntr+1:lntr+lnva
        t-lntr
           
        FeaturesT = Features(t-lntr:t-1,:)./norm(Features(t-lntr:t-1,:),Inf);
        %estimate coefficients via OLS
        clear beta0 beta1 Res
        cvx_begin quiet
        variables beta0 beta1(lF) Res(lntr)
        minimize( sum(Res.^2))
        subject to
            for i=1:lntr   
                Res(i) == Demand(t-lntr-1+i+delay)-beta0-beta1'*FeaturesT(i,:)';
            end
        cvx_end

    %estimate sigma coefficients via OLS
        clear delta0 delta1 Res2
        cvx_begin quiet
        variables delta0 delta1(lF) Res2(lntr)
        minimize( sum(Res2.^2))
        subject to
            for i=1:lntr   
                Res2(i) == log(Res(i)^2)-delta0-delta1'*FeaturesT(i,:)';
            end
        cvx_end
  
    %optimal order quantity
        Qfac(t-lntr,1) = beta0;
        ind = length(beta1);
        Qfac(t-lntr,[2:1+ind]) = beta1;        
        ResOpt(t-lntr,1) = cvx_optval;

        muD(t-lntr,1) = beta0+beta1'*(Features(t,:)'./(norm(Features(t-lntr:t-1,:),Inf))');
        sigmaD(t-lntr,1) = exp((delta0+delta1'*(Features(t,:)'./(norm(Features(t-lntr:t-1,:),Inf))'))/2);
        QfacD(t-lntr,1) = muD(t-lntr,1)+sigmaD(t-lntr,1)*norminv(r,0,1);
        Valfac(t-lntr,1) = nvcost(muD(t-lntr,1)+sigmaD(t-lntr,1)*norminv(r,0,1),Demand(t+delay),b,h);

    end

%%
    save(strcat(loc,'nv_emerg_estopt_os_',num2str(delay),'_lntr_',num2str(lntr),'_lnva_',num2str(lnva),'_p_',num2str(p),'_lF_',num2str(lF),'.mat')) 

end


